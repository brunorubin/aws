#!/usr/bin/env python

"""
This function is invoked by trend.py and will perform the calculation
for the team ID that was passed to it

"""

import boto3
import time
from decimal import Decimal
import os

DYNAMODB = boto3.resource('dynamodb')

def main(event, context):
    # get our timestamp of one minute ago
    timeFrom = ( int(time.time()) ) - 60
    print timeFrom
    #timeFrom = 1474998371

    # create our dynamo table client
    TEAM_TABLE = DYNAMODB.Table(os.environ["teamTable"])
    SCORE_TABLE = DYNAMODB.Table(os.environ["scoreEventTable"])
    HISTOGRAM_TABLE = DYNAMODB.Table(os.environ["histogramTable"])
    
    # do a query on the event table for the team passed in
    # with a

    response = SCORE_TABLE.query(
        ProjectionExpression='DeltaValue, CurrentScore, Reason',
        KeyConditionExpression='TeamId = :a AND EventTime > :t',
        ExpressionAttributeValues={
            ":t":timeFrom,
            ":a":event["account"]
            }
    )
    data = response['Items']
    trendSum = 0
    while 'LastEvaluatedKey' in response:
        response = SCORE_TABLE.query(
            ProjectionExpression='DeltaValue, CurrentScore, Reason',
            KeyConditionExpression='TeamId = :a AND EventTime > :t',
            ExpressionAttributeValues={
                ":t":timeFrom,
                ":a":event["account"]
            },
            ExclusiveStartKey=response['LastEvaluatedKey']
        )
        data.extend(response['Items'])

    # loop through the response in dynamo and add up all the Delta values
    if len(data)>0:
        for value in data:
            if "badge!" not in value["Reason"]:
                trendSum+=value["DeltaValue"]
        currentScore = data[len(data)-1]["CurrentScore"]
    else:
        currentScore = event["currentScore"]

    trendSum = int(trendSum)
    # now we need to put this updated trend into dynamo in the team specific information
    TEAM_TABLE.update_item(
        Key={
            "TeamId":event["account"]
            },
        UpdateExpression="SET Trend = :t",
        ExpressionAttributeValues={
            ":t":trendSum
            }
        )
    # now we put an entry into our histogram table
    HISTOGRAM_TABLE.put_item(
        Item={
            'TeamId':event["account"],
            'Timestamp': int(time.time()),
            'Trend': trendSum ,
            'CurrentScore': Decimal(str(currentScore))
        }
    )

if __name__ == '__main__':
    event={
        "teamTable":"Single-Tenant-API-Tables-TeamTable-SQLCF464AL48",
        "scoreEventTable":"Single-Tenant-API-Tables-ScoreEventTable-J9YRKKVH47FS",
        "histogramTable":"trend-history",
        "account":"9718438354",
        "currentScore":"-3072.1333333333333549"
        }
    main(event, "")
