#!/usr/bin/env python

"""
This function is fired based off cloudwatch events and is used to 
determine the trending of teams based on the last five minutes.

The CWE has an incoming structure of:
{
"teamTable":<team table dynamo name>,
"scoreEventTable":<score event table dynamo name>
}
these will act as environment variables

"""

import boto3
from json import dumps
import time
import os

DYNAMODB = boto3.resource('dynamodb')

def main(event, context):
    # retrieve vars from the event
    TEAM_TABLE = DYNAMODB.Table(os.environ["teamTable"])
    GAME_TABLE = DYNAMODB.Table(os.environ["gameTable"])
    
    # check to see if it's game start time or end time yet
    startResponse = GAME_TABLE.query(
        KeyConditionExpression='Config = :s',
        ExpressionAttributeValues={
            ":s":"startTime"
        }
    )
    endResponse = GAME_TABLE.query(
        KeyConditionExpression='Config = :s',
        ExpressionAttributeValues={
            ":s":"endTime"
        }
    )

    currentTime = int(time.time())
    gameStartTime = int(startResponse["Items"][0]["Value"])
    gameEndTime = int(endResponse["Items"][0]["Value"])
    if currentTime < gameStartTime:
        print "not game start time yet..."
        return
    if currentTime > gameEndTime:
        print "game is over..."
        return

    # need to get list of teams from dynamo
    response = TEAM_TABLE.scan(
        ProjectionExpression='TeamId, CurrentScore',
        )
    # creating lambda client
    lambda_client = boto3.client('lambda')
    # loop through each team
    for team in response["Items"]:
        print team["TeamId"]
        # build the payload we will be sending to the child lambda
        childEvent={}
        childEvent["currentScore"]=float(team["CurrentScore"])
        childEvent["account"]=team["TeamId"]
        childPayload = dumps(childEvent)
          # now we kick off the child lambda for each team      
        response = lambda_client.invoke(
            FunctionName=os.environ['trendChild'],
            InvocationType='Event',
            ClientContext='string',
            Payload=childPayload
        )
        print response
                   
if __name__ == '__main__':
    main({}, "")
