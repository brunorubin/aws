import json
import boto3
import os
import requests
import calendar
import time

def send_response(event, context, response_status):
    # building the quicklabs template download URL
    region = os.environ['region']
    s3string=''
    if region=='us-east-1':
        s3string='s3'
    else:
        s3string='s3-'+region
    templateURL = "https://"+s3string+".amazonaws.com/"+os.environ['resourcesBucket']+"/qwiklabs-template.json"


    #Build Response Body
    responseBody = {'Status': response_status,
                    'Reason': 'See the details in CloudWatch Log Stream: ' + context.log_stream_name,
                    'PhysicalResourceId': context.log_stream_name,
                    'StackId': event['StackId'],
                    'RequestId': event['RequestId'],
                    'LogicalResourceId': event['LogicalResourceId'],
                    'Data': {
                        "templateURL":templateURL
                    }
    }
    print 'RESPONSE BODY:\n' + json.dumps(responseBody)

    try:
        #Put response to pre-signed URL
        req = requests.put(event['ResponseURL'], data=json.dumps(responseBody))
        if req.status_code != 200:
            print req.text
            raise Exception('Recieved non 200 response while sending response to CFN.')
        return str(event)
    except requests.exceptions.RequestException as e:
        print req.text
        print e
        raise

def modifyFile(sourceBucket, destBucket, fileKey, fileName, replaceDict):
    """
    This function recursively moves items from the source bucket in the master
    account to the newly created bucket in their account
    """
    print fileName
    s3client = boto3.client('s3')
    s3client.download_file(Bucket=sourceBucket, Key=fileKey, Filename="/tmp/"+fileName)

    with open("/tmp/"+fileName, 'r') as in_file:
        text = in_file.read()

    updatedText=text
    # making necessary replacements
    for key, value in replaceDict.iteritems():
        updatedText = updatedText.replace(key, value)

    with open("/tmp/"+fileName+'-new', 'w') as out_file:
        out_file.write(updatedText)

    s3meta = boto3.resource('s3')
    s3meta.meta.client.upload_file("/tmp/"+fileName+'-new', destBucket, fileName)


def copyFiles(sourceBucket, destBucket, prefix, trimNum):
    """
    This function recursively copies s3 buckets
    """
    s3 = boto3.resource('s3')
    client = boto3.client('s3')

    paginator = client.get_paginator('list_objects')
    for result in paginator.paginate(Bucket=sourceBucket, Delimiter='/', Prefix=prefix):
        # checking if there are nested folders
        if result.get('CommonPrefixes') is not None:
            for subdir in result.get('CommonPrefixes'):
                # copy files in the nested folders
                copyFiles(sourceBucket, destBucket, subdir['Prefix'], trimNum)
        if result.get('Contents') is not None:
            for file in result.get('Contents'):
                # stripping of filename
                #print file
                fileName = file['Key'][trimNum:]
                if fileName=='':
                    continue
                if fileName==prefix:
                    continue
                #print fileName
                # copy the file
                # a few files need to have some values changed based upon what was created
                # in the cloudformation template
                if fileName=="qwiklabs-template.json":
                    modifyFile(sourceBucket, destBucket, file['Key'], fileName, {"<SNS_ARN>": os.environ['registratorArn'], "<MASTER_ACCOUNT>": os.environ['masterAccount']})
                elif fileName=="scoreboard.js":
                    modifyFile(sourceBucket, destBucket, file['Key'], fileName, {"<DOMAIN>": os.environ['domain']})
                    # need to set MIME type since replacing the value causes it to be incorrectly 
                    # set on uploading
                    s3.meta.client.copy_object(Bucket=destBucket,
                                                      Key="scoreboard.js",
                                                      ContentType='application/javascript',
                                                      MetadataDirective="REPLACE",
                                                      CopySource=destBucket + "/scoreboard.js")
                elif fileName=="team.js":
                    modifyFile(sourceBucket, destBucket, file['Key'], fileName, {"<DOMAIN>": os.environ['domain']})
                    # need to set MIME type since replacing the value causes it to be incorrectly 
                    # set on uploading
                    s3.meta.client.copy_object(Bucket=destBucket,
                                                      Key="team.js",
                                                      ContentType='application/javascript',
                                                      MetadataDirective="REPLACE",
                                                      CopySource=destBucket + "/team.js")
                else:
                    copy_source = {
                        'Bucket': sourceBucket,
                        'Key': file['Key']
                    }
                    s3.meta.client.copy(copy_source, destBucket, fileName)

def populateDynamo():
    """
    This function prepopulates the dynamo tables used to run the game
    """ 
    client = boto3.client('dynamodb')
    region = os.environ['region']
    s3string=''
    if region=='us-east-1':
        s3string='s3'
    else:
        s3string='s3-'+region

    # common resources
    sourceBucket = os.environ['sourceBucket']
    s3client = boto3.client('s3')

    ######
    # POPULATING BADGES TABLE
    ######
    s3client.download_file(Bucket=sourceBucket, Key="dynamo_templates/badgesTemplate", Filename="/tmp/badgesTemplate")

    with open("/tmp/badgesTemplate", 'r') as in_file:
        text = in_file.read()

    badgeUpdatedText=text
    # making necessary replacements
    badgeUpdatedText = badgeUpdatedText.replace("<S3-BASE-URL>", s3string+".amazonaws.com/"+os.environ['resourcesBucket']).replace("<BADGE-TABLE>", os.environ['badgeTable'])

    badgeUpdateObject = json.loads(badgeUpdatedText)
    #print updateObject

    for set in badgeUpdateObject:
        response = client.batch_write_item(RequestItems=set)

    ######
    # POPULATING CODE-LOOKUP TABLE
    ######
    s3client.download_file(Bucket=sourceBucket, Key="dynamo_templates/codesTemplate", Filename="/tmp/codesTemplate")
    with open("/tmp/codesTemplate", 'r') as in_file:
        text = in_file.read()

    codeUpdatedText=text
    # making necessary replacements
    codeUpdatedText = codeUpdatedText.replace("<CODE-LOOKUP-TABLE>", os.environ['codeLookupTable'])

    codeUpdateObject = json.loads(codeUpdatedText)
    #print updateObject

    response = client.batch_write_item(RequestItems=codeUpdateObject)

    ######
    # POPULATING CONFIG TABLE
    ######
    s3client.download_file(Bucket=sourceBucket, Key="dynamo_templates/configTemplate", Filename="/tmp/configTemplate")
    with open("/tmp/configTemplate", 'r') as in_file:
        text = in_file.read()

    startTime=calendar.timegm(time.gmtime())
    # setting startTime an hour ahead so the game doesn't start kicking off immediately
    startTime=startTime+(60*60*5)
    endTime=startTime+(60*60*12)

    configUpdatedText=text
    # making necessary replacements
    configUpdatedText = configUpdatedText.replace("<GAME-CONFIG-TABLE>", os.environ['configTable']).replace("<CODE-SNIPPETS-URL>", s3string+".amazonaws.com/"+os.environ['resourcesBucket']).replace("<PLAYER-REGION>", os.environ['region']).replace("<START-TIME>", str(startTime)).replace("<MINIGAME-URL>", s3string+".amazonaws.com/"+os.environ['resourcesBucket']).replace("<END-TIME>", str(endTime)).replace("<MASTER-ACCOUNT>", os.environ['masterAccount'])

    configUpdateObject = json.loads(configUpdatedText)

    response = client.batch_write_item(RequestItems=configUpdateObject)

def deleteAll(bucket, prefix):
    client = boto3.client('s3')

    paginator = client.get_paginator('list_objects')
    for result in paginator.paginate(Bucket=bucket, Delimiter='/', Prefix=prefix):
        # checking if there are nested folders
        if result.get('CommonPrefixes') is not None:
            for subdir in result.get('CommonPrefixes'):
                # copy files in the nested folders
                deleteAll(bucket, subdir['Prefix'])
        if result.get('Contents') is not None:
            for file in result.get('Contents'):
                client.delete_object(
                    Bucket=bucket,
                    Key=file['Key'],
                )
def handler(event, context):
    print json.dumps(event)

    if event['RequestType'] == 'Create':
        # copy files to our scoreboard and update the URLs
        copyFiles(os.environ['sourceBucket'], os.environ['scoreboardBucket'], 'scoreboard/', 11)
        # copy our quicklabs template
        copyFiles(os.environ['sourceBucket'], os.environ['resourcesBucket'], 'qwik', 0)
        # copy our code snippets
        copyFiles(os.environ['sourceBucket'], os.environ['resourcesBucket'], 'snippets/', 0)
        # copy our home page
        copyFiles(os.environ['sourceBucket'], os.environ['homepageBucket'], 'homepage/', 9)
        # copy our minigames
        copyFiles(os.environ['sourceBucket'], os.environ['resourcesBucket'], 'minigames/', 0)

        populateDynamo()
        send_response(event, context, "SUCCESS")

    if event['RequestType'] == 'Delete':
        # need to delete objects in the S3 bucket so the CFN stack
        # can delete the bucket
        deleteAll(os.environ['scoreboardBucket'],'')
        deleteAll(os.environ['resourcesBucket'],'')
        deleteAll(os.environ['homepageBucket'],'')

        send_response(event, context, "SUCCESS")
    if event['RequestType'] == 'Update':
        send_response(event, context, "SUCCESS")

    return str(event)