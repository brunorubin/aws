import json
import requests
from boto3 import client
import time
import os

def lambda_handler(event, context):
    endpoint = os.environ['Endpoint'].rstrip('/')
    # first we need to check and see if we should even be running
    
    startUrl = endpoint+"/startTime"
    stopUrl = endpoint+"/endTime"
    startResponse = requests.get(startUrl)
    startTime = int(json.loads(startResponse.text)['Value'])
    stopResponse = requests.get(stopUrl)
    endTime = int(json.loads(stopResponse.text)['Value'])
    print startTime
    print endTime
    
    currentTime = int(time.time())
    if currentTime < startTime:
        print "not game start time yet..."
        return
    if currentTime > endTime:
        print "game is over..."
        return  

    teamurl = endpoint + '/team'

    response = requests.get(teamurl)
    print response.text
    teams = json.loads(response.text)
    print teams
    for team in teams:
        try:
            if 'roleArn' in team['Metadata']:
                print "Checking Team: " + team['Metadata']['roleArn'].split(':')[4]
                event['AccountNumber'] = team['Metadata']['roleArn'].split(':')[4]
                event['RoleArn'] = team['Metadata']['roleArn']
                event['Team'] = team['TeamId']
                eventbytes = json.dumps(event)

                lambda_client = client('lambda')
                response = lambda_client.invoke(
                    FunctionName=os.environ['ChildLambda'],
                    InvocationType='Event',
                    ClientContext='string',
                    Payload=eventbytes
                    )
                print response
            else:
                print "Error: No Role ARN for Account ID " + team['Metadata']['roleArn'].split(':')[4]
        except Exception:
            print "Error: No Metadata for Team Id " + team['TeamId']
            pass
