from boto3 import Session
from boto3 import client
import requests
import time
import os

def lambda_handler(event, context):
    # get player region
    request = urllib2.urlopen(baseURL+"/playerRegion")
    rgn = json.loads(request.read())['Value']
    account_id = event['AccountNumber']
    print event
    sts_client = client('sts')
    response = sts_client.assume_role(
        RoleArn=event['RoleArn'],
        RoleSessionName='AWSGameday'
    )
    # storing STS credentials
    session = Session(
        aws_access_key_id=response['Credentials']['AccessKeyId'],
        aws_secret_access_key=response['Credentials']['SecretAccessKey'],
        aws_session_token=response['Credentials']['SessionToken'],
        region_name=rgn
    )
    print "Assumed session for "+account_id+" in region "+rgn+". Beginning checks..."

    dynamo_client = session.client('dynamodb', region_name=rgn)
    table_iterator = dynamo_client.list_tables()
    dynamo_done = False
    dynamo_aggregated_results = []
    while not dynamo_done:
        dynamo_aggregated_results = dynamo_aggregated_results + table_iterator['TableNames']
        next_token = table_iterator.get("LastEvaluatedTableName", None)
        if next_token is None:
            dynamo_done = True
        else:
            table_iterator = dynamo_client.list_tables(ExclusiveStartTableName=next_token)
    total_rcu = 0
    total_wcu = 0
        # iterating through all the user's tables
    for table_name in dynamo_aggregated_results:
        table = dynamo_client.describe_table(TableName=table_name)
        table_throughput = table['Table']['ProvisionedThroughput']
        total_rcu += table_throughput['ReadCapacityUnits']
        total_wcu += table_throughput['WriteCapacityUnits']
        try:
        # checking for any indexes that might be associated with the table
            for gsi in table['Table']['GlobalSecondaryIndexes']:
                gsi_throughput = gsi['ProvisionedThroughput']
                total_rcu += gsi_throughput['ReadCapacityUnits']
                total_wcu += gsi_throughput['WriteCapacityUnits']
        except:
            pass

    #Lose 60 points each run (5 minutes) for every RCU above 5
    rcu_deduction_score = (0 - total_rcu) * 10
    wcu_deduction_score = (0 - total_wcu) * 10
    rcu_deduction_body = {'DeltaValue': rcu_deduction_score, 'Reason': 'DynamoDB Read Compute Unit Cost'}
    wcu_deduction_body = {'DeltaValue': wcu_deduction_score, 'Reason': 'DynamoDB Write Compute Unit Cost'}

    ec2_client = session.client('ec2', region_name=rgn)
    response = ec2_client.describe_account_attributes()
    ec2_done = False
    ec2_aggregated_results = []
    ec2_response = ec2_client.describe_instances(
        Filters=[
            {
                'Name': 'instance-state-name',
                'Values': ['pending', 'running']
            }
        ]
    )
    # grabbing additional instances if next_token is sent
    while not ec2_done:
        ec2_aggregated_results = ec2_aggregated_results+ec2_response['Reservations']
        next_token = ec2_response.get("NextToken", None)
        if next_token is None:
            ec2_done = True
        else:
            ec2_response = ec2_client.describe_instances(
                Filters=[
                    {
                        'Name': 'instance-state-name',
                        'Values': ['pending', 'running']
                    }
                ],
                NextToken=next_token
            )
    num_of_instances = 0
    for rsrv in ec2_aggregated_results:
        instance_list = rsrv['Instances']
        num_of_instances += len(instance_list)

    #Lose 300 points every run (5 minutes) for every instance above 2
    instance_deduction_score = (0 - num_of_instances) * 30
    instance_deduction_body = {'DeltaValue': instance_deduction_score, 'Reason': 'EC2 Instance Cost'}

    elasticache_client = session.client('elasticache', region_name=rgn)
    response = elasticache_client.describe_cache_clusters()

    num_of_clusters = 0
    for clusters in response['CacheClusters']:
        num_of_clusters = num_of_clusters + clusters['NumCacheNodes']
    elasticache_deduction_score = (0 - num_of_clusters) * 30
    elasticache_deduction_body = {'DeltaValue': elasticache_deduction_score, 'Reason': 'Elasticache Cluster Cost'}

    endpoint = os.environ['Endpoint'].rstrip('/')
    teamid = event['Team']
    teamurl = endpoint + '/team/' + teamid + '/score'
    print teamurl

    header = {'x-gameday-api-token': os.environ['apiToken']}

    print rcu_deduction_score
    if rcu_deduction_score < 0:
        response = requests.put(teamurl, json=rcu_deduction_body, headers=header)
        print response.text
        time.sleep(1)
    print wcu_deduction_score
    if wcu_deduction_score < 0:
        response = requests.put(teamurl, json=wcu_deduction_body, headers=header)
        print response.text
        time.sleep(1)
    print instance_deduction_score
    if instance_deduction_score < 0:
        response = requests.put(teamurl, json=instance_deduction_body, headers=header)
        print response.text
        time.sleep(1)
    print elasticache_deduction_score
    if elasticache_deduction_score < 0:
        response = requests.put(teamurl, json=elasticache_deduction_body, headers=header)
        print response.text
        time.sleep(1)
