#!/usr/bin/env python
"""
Client which receives and processes the requests
"""
import os
import logging
import argparse
import urllib2
import sqlite3
from flask import Flask, request, g

# configure logging
logging.basicConfig(level=logging.INFO)

# environment vars
API_TOKEN = os.getenv("GD_API_TOKEN")
if API_TOKEN is None:
    raise Exception("Must define GD_API_TOKEN environment variable")
API_BASE = os.getenv("GD_API_BASE")
if API_BASE is None:
    raise Exception("Must define GD_API_BASE environment variable")
DATABASE = os.getenv("GD_DATABASE", "data.db")

app = Flask(__name__)

# method to get sqlite database session
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db

# method that gets executed before server shuts down to make
# sure that the database is flushed and closed properly
@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

# creates initial schema for database
def init_db():
    with app.app_context():
        db = get_db()
        db.execute('CREATE TABLE IF NOT EXISTS messages (msg_id CHAR(64) NOT NULL, part_number INT NOT NULL, data TEXT NOT NULL, PRIMARY KEY(msg_id, part_number))')
        db.commit()
# init db
init_db()

# creating flask route for type argument
@app.route('/', methods=['GET', 'POST'])
def main_handler():
    """
    main routing for requests
    """
    if request.method == 'POST':
        return process_message(request.get_json())
    else:
        return get_message_stats()

def get_message_stats():
    """
    processes the messages by combining parts
    """
    cur = get_db().execute('select count(*) from messages')
    msg_count = cur.fetchone()[0]
    return "There are {} messages in the sqlite database".format(msg_count)

def process_message(msg):
    """
    processes the messages by combining and appending the kind code
    """
    msg_id = msg['Id'] # The unique ID for this message
    part_number = msg['PartNumber'] # Which part of the message it is
    data = msg['Data'] # The data of the message

    # log
    logging.info("Processing message for msg_id={} with part_number={} and data={}".format(msg_id, part_number, data))

    # store this part of the message in the sqlite database
    db = get_db()
    cur = db.execute("INSERT INTO messages VALUES ('{}', {}, '{}')".format(msg_id, part_number, data))
    db.commit()

    # try to get the parts of the message from the sqlite database.
    cur = db.execute("SELECT * FROM messages WHERE msg_id = '{}'".format(msg_id))
    db_messages = cur.fetchall() # [(u'123', 0, u'abcdefg')]

    # if we have both parts, the message is complete
    if len(db_messages) == 2:
        # app.logger.debug("got a complete message for %s" % msg_id)
        logging.info("Have both parts for msg_id={}".format(msg_id))
        # We can build the final message.
        result = db_messages[0][2] + db_messages[1][2]
        logging.debug("Assembled message: {}".format(result))
        # sending the response to the score calculator
        # format:
        #   url -> api_base/jFgwN4GvTB1D2QiQsQ8GHwQUbbIJBS6r7ko9RVthXCJqAiobMsLRmsuwZRQTlOEW
        #   headers -> x-gameday-token = API_token
        #   data -> EaXA2G8cVTj1LGuRgv8ZhaGMLpJN2IKBwC5eYzAPNlJwkN4Qu1DIaI3H1zyUdf1H5NITR
        url = API_BASE + '/' + msg_id
        logging.debug("Making request to {} with payload {}".format(url, result))
        req = urllib2.Request(url, data=result, headers={'x-gameday-token':API_TOKEN})
        resp = urllib2.urlopen(req)
        logging.debug("Response from server: {}".format(resp.read()))
        resp.close()

    return 'OK'

if __name__ == "__main__":
    # By default, we disable threading for "debugging" purposes.
    app.run(host="0.0.0.0", port="5000", threaded=False)
